

let nombreusuario=document.getElementById('login');
let boton=document.getElementById("comprobar");
boton.addEventListener("click",(e)=>{
    e.preventDefault();
    fetch('http://ejercicio2.loc/compruebaDisponibilidadXML.php')
    .then(response => {
        if (response.ok) {
            return response.text();
        }
        return Promise.reject(response);
    })
    .then(datos =>{
        const parser = new DOMParser();
        const xml = parser.parseFromString(datos, "application/xml");
        let frases = xml.getElementsByTagName('disponible');
        console.log(frases[0].textContent);
        if (frases[0].textContent=="si"){
            alert("Sin problemas");
        }
        else if (frases[0].textContent=="no"){
            nombresdisponibles=xml.getElementsByTagName('alternativas');
            let alternacion=nombresdisponibles[0].getElementsByTagName('login');
            let listatotal = document.getElementById("lista");
            listatotal.setAttribute("id","lista");
            for (let index = 1; index < alternacion.length; index++) {
                console.log(alternacion[index].textContent);
                let nodolista = document.createElement("li");
                let nombrelista=document.createTextNode(nombreusuario.value+alternacion[index].textContent);
                nodolista.setAttribute("name",nombreusuario.value+alternacion[index].textContent);
                nodolista.appendChild(nombrelista);
                listatotal.appendChild(nodolista);
            }
            document.body.appendChild(listatotal);
        }
    })
    .catch(console.log("Error: "))
})

let eventlista=document.getElementById("lista");

eventlista.addEventListener("click",(e)=>{
    nombreusuario.value=e.target.textContent;
});
